Development sample bundle for Unclad Collection.
